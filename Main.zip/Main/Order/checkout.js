document.addEventListener('DOMContentLoaded', function () {
    const shippingForm = document.getElementById('shipping-form');
    const placeOrderBtn = document.getElementById('place-order-btn');

    if (shippingForm) {
        // Add input validation on blur
        const inputs = shippingForm.querySelectorAll('input, textarea');
        inputs.forEach(input => {
            input.addEventListener('blur', validateField);
            input.addEventListener('input', clearError);
        });

        shippingForm.addEventListener('submit', function (e) {
            e.preventDefault();
            if (validateForm()) {
                handleOrderPlacement();
            }
        });

        function validateField(e) {
            const field = e.target;
            const errorElement = field.nextElementSibling;
            
            if (!field.checkValidity()) {
                field.style.border = '1px solid red';
                errorElement.textContent = field.validationMessage;
                return false;
            }
            
            field.style.border = '';
            errorElement.textContent = '';
            return true;
        }

        function clearError(e) {
            const field = e.target;
            const errorElement = field.nextElementSibling;
            field.style.border = '';
            errorElement.textContent = '';
        }

        function validateForm() {
            let isValid = true;
            const requiredFields = shippingForm.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!validateField({ target: field })) {
                    isValid = false;
                }
            });

            if (!isValid) {
                return false;
            }

            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            if (cart.length === 0) {
                alert('Your cart is empty');
                return false;
            }

            return true;
        }

        function handleOrderPlacement() {
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const formData = new FormData(shippingForm);
            const shippingInfo = Object.fromEntries(formData.entries());
        
            let subtotal = 0;
            // Ensure all prices are numbers
            const processedCart = cart.map(item => {
                // Convert price to number if it's a string
                const price = typeof item.price === 'string' 
                    ? parseFloat(item.price.replace(/[^\d.-]/g, '')) 
                    : item.price;
                    
                subtotal += price * item.quantity;
                return {
                    ...item,
                    price: price
                };
            });
        
            const total = subtotal;
            const orderId = 'ORD' + Math.floor(Math.random() * 1000000);
        
            const orderData = {
                items: processedCart, // Use the processed cart with cleaned prices
                shippingInfo,
                subtotal,
                shipping: 0,
                total,
                orderId
            };
        
            // Rest of the function remains the same
            fetch('save_order.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(orderData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('confirmation-message').textContent =
                        'Thank you, your order has been placed successfully!';
                    document.getElementById('order-id').textContent = orderId;
                    document.getElementById('order-confirmation').style.display = 'flex';
                    localStorage.removeItem('cart');
                    shippingForm.reset();
                } else {
                    alert('Failed to save order: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while processing your order');
            });
        }

        // Close modal
        document.querySelector('.close-modal')?.addEventListener('click', () => {
            document.getElementById('order-confirmation').style.display = 'none';
        });

        // Continue shopping
        document.getElementById('continue-shopping')?.addEventListener('click', () => {
            window.location.href = 'http://localhost/Main/Main.html';
        });
    }
});