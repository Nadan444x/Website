<?php
header('Content-Type: application/json');

// Get the raw POST data
$input = file_get_contents('php://input');
$data = json_decode($input, true);

// Check if JSON decode was successful
if (json_last_error() !== JSON_ERROR_NONE || $data === null) {
    die(json_encode(['error' => 'Invalid JSON data']));
}

// Database connection
$conn = new mysqli('localhost', 'root', 'Rohit@444', 'website');

if ($conn->connect_error) {
    die(json_encode(['error' => 'Connection failed: ' . $conn->connect_error]));
}

try {
    // Start transaction
    $conn->begin_transaction();

    // Prepare order data
    $orderId = $conn->real_escape_string($data['orderId']);
    $shipping = $data['shippingInfo'];

    // Validate required fields
    if (!isset($shipping['phone'])) {
        throw new Exception("Phone number is required");
    }

    // Insert order
    $stmt = $conn->prepare("INSERT INTO orders (order_id, fullname, address, city, state, zip, phone) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        throw new Exception("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param(
        "sssssss",
        $orderId,
        $shipping['fullname'],
        $shipping['address'],
        $shipping['city'],
        $shipping['state'],
        $shipping['zip'],
        $shipping['phone'],
    );

    if (!$stmt->execute()) {
        throw new Exception("Execute failed: " . $stmt->error);
    }

    // Insert order items - now with price verification
    foreach ($data['items'] as $item) {
        if (!isset($item['price'])) {
            throw new Exception("Price missing for item: " . $item['title']);
        }
        
        // More comprehensive price validation
        if (!is_numeric($item['price'])) {
            throw new Exception("Invalid price format for item: " . $item['title']);
        }
        
        $price = (float)$item['price'];
        if ($price <= 0) {
            throw new Exception("Price must be positive for item: " . $item['title']);
        }
    
        $stmt = $conn->prepare("INSERT INTO order_items (order_id, title, price) VALUES (?, ?, ?)");
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }
    
        $stmt->bind_param("ssd", 
            $orderId, 
            $item['title'],
            $price  // Use the validated float value
        );
    
        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }
    }

    // Commit transaction
    $conn->commit();

    echo json_encode(['success' => true, 'orderId' => $orderId]);
} catch (Exception $e) {
    // Rollback on error
    $conn->rollback();
    echo json_encode(['error' => $e->getMessage()]);
}

$conn->close();
?>