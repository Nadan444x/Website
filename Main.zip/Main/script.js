// Book data - moved to the top for easy access
const books = {
  // C books
  "book1": {
    id: "c1", // Added ID
    title: "Modern Approach to C Programming",
    Price: 780,
    image: "http://localhost/Main/Assets/Books/C/c.webp",
    description: "This book provides a comprehensive guide to C programming, starting with the fundamentals of the C language and progressing to advanced topics",
    Author: "Author : Amisha Saxena, Dr. Nancy Arya, Anil Tanwar",
    

  },
  "book2": {
    id: "c2", // Added ID
    title: "Modern C",
    Price: 500,
    image: "http://localhost/Main/Assets/Books/C/ModernC.jpg",
    description: "Decsprition : Modern C focuses on the new and unique features of modern C programming. The book is based on the latest C standards and offers an up-to-date perspective on this tried-and-true language.",
    Author: "Author : Jens Gustedt",
    pdfUrl: "http://localhost/Main/Assets/Pdf/ModernC.pdf"
  },
  "book3": {
    id: "c3", // Added ID
    title: "C In Depth",
    Price: 415,
    image: "http://localhost/Main/Assets/Books/C/CDepth.jpg",
    description: "Descprition :This book is written in a simple manner and is very easy to understand. It is the best book among all the C programming books.Proves to be very useful for beginner as well as advance programmers.",
    Author:"Author : S.K.Srivastava/Deepali Srivastava"
  },
  "book4": {
    id: "c4", // Added ID
    title: "Expert C Programming",
    Price: 2000,
    image: "http://localhost/Main/Assets/Books/C/Expert%20C%20Programming.jpg",
    description: "Descprition :Written for experienced C programmers who want to pick up some of techniques of experts and master the fine arts of ANSI C, this book helps programmers avoid common software pitfalls. It gathers into one place, tips, hints, shortcuts, guidelines, ideas, idioms, heuristics, tools, anecdotes, C folklore, and techniques.",
    Author:"Author : Peter van der Linden"
  },
  "book5": {
    id: "c5", // Added ID
    title: "Beej's Guide to C Programming",
    Price: 1500 ,
    image: "http://localhost/Main/Assets/Books/C/BeejC.png",
    description: "This book introduces you to the most commonly used programming language, one that has been the basis for many other versions over the years. It is a great book, not just for beginning programmers, but also for computer users who would want to have an idea what is happening behind the scenes as they work with various computer programs.",
    Author:"Author : Brian (Beej Jorgensen) Hall"
  },
  "book6": {
    id: "c6", // Added ID
    title: "Extreme C",
    Price: " 3300 ",
    image: "http://localhost/Main/Assets/Books/C/Extreme%20C.jpg",
    description: "Master advanced capabilities of C with this practical guide to preprocessor directives, macros, pointers, and more.",
    Author: "Author : Kamran Amini"
  },
  
  // C++ books
  "book11": {
    id: "cpp1", // Added ID
    title: "Data Structures and Algorithm Analysis in C++, Third Edition",
    Price: "2726 ",
    image: "http://localhost/Main/Assets/Books/C++/Data%20Structures%20and%20Algorithm%20Analysis%20in%20C.jpg",
    description: "A comprehensive treatment focusing on the creation of efficient data structures and algorithms, this text explains how to select or design the data structure best suited to specific problems. It uses C++ as the programming language and is suitable for second-year data structure courses and computer science courses in algorithmic analysis.",
    Author:"Author :Clifford A. Shaffer"
  },
  "book12": {
    id: "cpp2", // Added ID
    title: "Fundamentals of Programming C++",
    Price: 500,
    image: "http://localhost/Main/Assets/Books/C++/Fundamentals%20of%20Programming%20C++.png",
    description: "This book teaches the basics of C++ programming in an easy-to-follow style, without assuming previous experience in any other language. A variety of examples such as game programming, club membership organization, grade tracking and grade point average calculation, make learning C++ both fun and practical. Each chapter contains at least one complete, fully functional example program, with several smaller examples provided throughout the book.",
    Author:"Author :Richard L. Halterman"
  },
  "book13": {
    id: "cpp3", // Added ID
    title: "Data Parallel C++, 2nd Edition: Programming Accelerated Systems Using C++ ",
    Price: 1500,
    image: "http://localhost/Main/Assets/Books/C++/Data%20Parallel%20C++.jpg",
    description: "Learn how to accelerate C++ programs using Data Parallelism and SYCL.This open access book enables C++ programmers to be at the forefront of this exciting and important development that is helping to push computing to new levels. This updated second edition is full of practical advice, detailed explanations, and code examples to illustrate key topics.",
    Author:"Author :James Reinders, Ben Ashbaugh, James Brodman, Michael Kinsner, John Pennycook, Xinmin Tian"
  },
  "book14": {
    id: "cpp4", // Added ID
    title: "Modern C++ Tutorial",
    Price: 350,
    image: "http://localhost/Main/Assets/Books/C++/Modern%20C++%20Tutorial.png",
    description: "The book claims to be On The Fly. Its intent is to provide a comprehensive introduction to the relevant features regarding modern C++ (before 2020s). Readers can choose interesting content according to the following table of content to learn and quickly familiarize the new features you would like to learn. Readers should be aware that not all of these features are required. Instead, it should be learned when you really need it.",
    Author:"Author : Changkun Ou"
  },
  "book15": {
    id: "cpp5", // Added ID
    title: "C++ Programming",
    Price: 750,
    image: "http://localhost/Main/Assets/Books/C++/C++%20Programming.png",
    description: "This book covers the C++ programming language, its interactions with software design and real life use of the language. It is presented in a series of chapters as an introductory prior to advance courses but can also be used as a reference book.",
    Author:"Author : Wikibooks Contributors"
  },
  "book16": {
    id: "cpp6", // Added ID
    title: "Jumping into C++",
    Price: 2300,
    image: "http://localhost/Main/Assets/Books/C++/Jumping%20into%20C++.jpg",
    description: "As a professional C++ developer and former Harvard teaching fellow, I know what you need to know to be a great C++ programmer, and I know how to teach it, one step at a time. I know where people struggle, and why, and how to make it clear.",
    Author:"Author : Alex Allain"
  },
  
  // Java books
  "book20": {
    id: "java1", // Added ID
    title: "Programming with Java",
    Price: 800 ,
    image: "http://localhost/Main/Assets/Books/JAVA/Programming%20with%20Java.png",
    description: "This is a beginner-friendly eTextbook that introduces readers to the fundamentals of Java. It covers key concepts like syntax, data types, control structures, and object-oriented programming, offering clear explanations and practical examples.",
    Author:"Author :Ashik Ahmed Bhuiyan, Md Amiruzzaman"
  },
  "book21": {
    id: "java2", // Added ID
    title: "Programming Basics with Java",
    Price: 1300,
    image: "http://localhost/Main/Assets/Books/JAVA/Programming%20Basics%20with%20Java.png",
    description: "This guide introduces readers to writing entry-level programming code (working with data, conditional statements, loops, and methods) using the Java programming language. Effective step-by-step Java education.",
    Author:"Author : Svetlin Nakov"
  },
  "book22": {
    id: "java3", // Added ID
    title: "Programming Problems in Java",
    Price: 400,
    image: "http://localhost/Main/Assets/Books/JAVA/Programming%20Problems%20in%20Java.jpg",
    description: "A complete primer for the technical programming interview. This book reviews the fundamentals of computer programming through programming problems posed to candidates at Amazon, Apple, Facebook, Google, Microsoft, and others.",
    Author:"Author :James Wong and Bradley Green"
  },
  "book23": {
    id: "java4", // Added ID
    title: "Java for Beginners: A Crash Course to Learn Java Programming in 1 Week",
    Price: 350,
    image: "http://localhost/Main/Assets/Books/JAVA/Java%20for%20Beginners%20A%20Crash%20Course.png",
    description: "The best way to learn Java is by doing. This book includes a unique project at the end of the book that requires the application of all the concepts taught previously. You can get the basics down in only one week!",
    Author:"Author :Riccardo Flask"
  },
  "book24": {
    id: "java5", // Added ID
    title: "Think Java: How to Think Like a Computer Scientist",
    Price: 450 ,
    image: "http://localhost/Main/Assets/Books/JAVA/Think%20Java%20Like%20a%20Computer%20Scientist.jpg",
    description: "Think Java is a hands-on introduction to computer science and programming used by many universities and high schools around the world. Its conciseness, emphasis on vocabulary, and informal tone make it particularly appealing for readers with little or no experience. The book starts with the most basic programming concepts and gradually works its way to advanced object-oriented techniques.",
    Author:"Author :Allen B. Downey, Chris Mayfield"
  },
  "book25": {
    id: "java6", // Added ID
    title: "Java 23 Key Concepts in Brief",
    Price: 500,
    image: "http://localhost/Main/Assets/Books/JAVA/Java%2023%20Key%20Concepts%20in%20Brief.png",
    description: "This book provides a concise guide to the key concepts and features introduced in Java 23. It is intended for developers who are already familiar with Java and want to learn about the latest advancements in the language.",
    Author:"Author :Sergio Petrucci"
  },
  
  // Python books
  "book31": {
    id: "python1", // Added ID
    title: "Object-Oriented Programming in Python",
    Price: 500,
    image: "http://localhost/Main/Assets/Books/Python/Object-Oriented%20Programming%20in%20Python.png",
    description: "This book is an intuitive and thorough guide to mastering object-oriented programming from the ground up. You'll cover the basics of building classes and creating objects, and put theory into practice with clear examples that help visualize the object-oriented style.",
    Author:"Author :Michael H. Goldwasser"
  },
  "book32": {
    id: "python2", // Added ID
    title: "Introduction to Computer Programming with Python",
    Price: 450,
    image: "http://localhost/Main/Assets/Books/Python/Introduction%20to%20Computer%20Programming%20with%20Python.png",
    description: "This introduction to computer programming with Python begins with some of the basics of computing and programming before diving into the fundamental elements and building blocks of computer programs in Python language. From the installation of Python, Python interactive programming, and integrated development environments to raising and handling exceptions, using compound data types to solve problems, and implement divide-and-conquer processes using functions, classes and modules, this textbook will set students up for success in programming and computing study and practice. The included exercises and projects are designed to hone students' skills.",
    Author:"Author :Harris Wang"
  },
  "book33": {
    id: "python3", // Added ID
    title: "Fundamentals of Python Programming",
    Price: 975,
    image: "http://localhost/Main/Assets/Books/Python/Fundamentals%20of%20Python%20Programming.png",
    description: "his book focuses on introducing programming techniques and developing good habits. To that end, our approach avoids some of the more esoteric features of Python and concentrates on the programming basics that transfer directly to other imperative programming languages.Its easygoing approach is ideal, no matter what your background. The approach starts with simple algorithmic code and then scales into working with functions, objects, and classes as the problems become more complex and require new abstraction mechanisms.",
    Author:"Author :Richard L. Halterman"
  },
  "book34": {
    id: "python4", // Added ID
    title: "Python for Software Development",
    Price: 1350,
    image: "http://localhost/Main/Assets/Books/Python/Python%20for%20Software%20Development.png",
    description: "This is a textbook in Python Programming with lots of Examples, Exercises, and Practical Applications within Software Systems, Software Development, Software Engineering, Database Systems, Web Application Desktop Applications, GUI Applications, etc. The focus is on the use of Python for creating modern Software Systems.",
    Author:"Author :Hans-Petter Halvorsen"
  },
  "book35": {
    id: "python5", // Added ID
    title: "Internet of Things with Python",
    Price: 350,
    image: "http://localhost/Main/Assets/Books/Python/Internet%20of%20Things%20with%20Python.jpg",
    description: "The book is ideal for Python developers who want to explore the tools in the Python ecosystem in order to build their own IoT applications and work on IoT-related projects. It is also a very useful resource for developers with experience in other programming languages that want to easily prototype IoT applications with the Intel Galileo Gen 2 board.",
    Author:"Author :Gastón C. Hillar"
  },
  "book36": {
    id: "python6", // Added ID
    title: "Python Programming",
    Price: 800,
    image: "http://localhost/Main/Assets/Books/Python/Python%20Programming.jpg",
    description: "This is a textbook in Python Programming with lots of Practical Examples and Exercises. You will learn the necessary foundation for basic programming with focus on Python. You'll also learn some advanced language features that recently have become more common in Python code.",
    Author:"Author :Hans-Petter Halvorsen"
  },

  // PHP books
  "book39": {
    id: "php1", // Added ID
    title: "Practical PHP: The Definitive Guide to Programming PHP",
    Price: 600,
    image: "http://localhost/Main/Assets/Books/Php/Practical%20PHP%20The%20Definitive%20Guide%20to%20Programming%20PHP.png",
    description: "This book was written with the goal of making the task of learning PHP something fun that you don't have to worry about. As such, you'll find lots of information for newcomers, even those who haven't programmed much before.On the other end of the scale, this book is packed with lots of information on advanced functionality in PHP if you are a veteran user looking to take your PHP skills above and beyond where they are right now, you will find there is lots to be had here.The goal for this book has been to produce something you can read in whatever order you want. This book assumes no PHP programming skill at all: you'll be taught from scratch in that respect. However, once you have the basics down, you're encouraged to flick through the table of contents, find something that interests you most, and start reading from there.",
    Author:"Author :Paul Hudson"
  },
  "book40": {
    id: "php2", // Added ID
    title: "The PHP Programming Language",
    Price: 770,
    image: "http://localhost/Main/Assets/Books/Php/The%20PHP%20Programming%20Language.png",
    description: "This book is a beginner's guide for writing PHP programs from scratch and learning practical programming skills to use with any language. This website is a treasure trove of knowledge and a great platform to enhance your PHP skills.",
    Author:"Author :CodeAhoy"
  },
  "book41": {
    id: "php3", // Added ID
    title: "PHP Essentials",
    Price: 320,
    image: "http://localhost/Main/Assets/Books/Php/PHP%20Essentials.png",
    description: "The book is intended to cover all aspects of PHP. It starts by covering the history of PHP before providing a high level overview of how PHP works and why it is so useful to web developers. It then moves on to cover each area of PHP in detail, from the basics of the scripting language through to object oriented programming, file and file system handling and MySQL and SQLite database integration. In addition, chapters are also provided covering the creation and handling of HTML based forms and maintaining state using both cookies and PHP sessions. Each topic area is accompanied by extensive real world examples intended to bring theory to life.",
    Author:"Author :Neil Smyth"
  },
  "book42": {
    id: "php4", // Added ID
    title: "PHP Power Programming",
    Price: 450,
    image: "http://localhost/Main/Assets/Books/Php/PHP%20Power%20Programming.jpg",
    description: "This book shows you how to make the most of PHP's industrial-strength enhancements in any project -- no matter how large or complex. Its unique insights and realistic examples illuminate PHP's new object model, powerful design patterns, improved XML Web services support, and much more. Whether you're creating web applications, extensions, packages, or shell scripts, or migrating old code - here are high-powered solutions you won't find anywhere else.",
    Author:"Author :Andi Gutmans, Stig S. Bakken, and Derick Rethans"
  },
  "book43": {
    id: "php5", // Added ID
    title: "Essential PHP",
    Price: 300,
    image: "http://localhost/Main/Assets/Books/Php/Essential%20PHP.png",
    description: "This book written to provide clear and concise explanation of topics for programmers both starting to learn the PHP programming as well as those diving in more complex topics. Most examples are linked to online playground that allows you to change the code and re-run it.You can also quickly navigate to desired content using table of content on the left and search at the top (tip: you can navigate search using only a keyboard with '/' shortcut to start a search).",
    Author:"Author :Krzysztof Kowalczyk"
  },
  "book44": {
    id: "php6", // Added ID
    title: "PHP: The Right Way",
    Price: 1500,
    image: "http://localhost/Main/Assets/Books/Php/PHP%20The%20Right%20Way.png",
    description: "There is no canonical way to use PHP. This book aims to introduce new PHP developers to some topics which they may not discover until it is too late, and aims to give seasoned pros some fresh ideas on those topics they've been doing for years without ever reconsidering. This ebook will also not tell you which tools to use, but instead offer suggestions for multiple options, when possible explaining the differences in approach and use-case.",
    Author:"Author :Phil Sturgeon and Josh Lockhart"
  },
  
  // Web books
  "book49": {
    id: "web1", // Added ID
    title: "How To Build a Website With CSS and HTML",
    Price: 500,
    image: "http://localhost/Main/Assets/Books/WEB/How%20To%20Build%20a%20Website%20With%20CSS%20and%20HTML.png",
    description: "This project-based eBook will introduce you to Cascading Style Sheets (CSS), a stylesheet language used to control the presentation of websites, by building a personal website using our demonstration site as a model. Though our demonstration site features Sammy the Shark, you can switch out Sammy's information with your own if you wish to personalize your site.",
    Author:"Author : Erin Glass"
  },
  "book50": {
    id: "web2", // Added ID
    title: "The Web Book: The ultimate beginner's guide to HTML, CSS, JavaScript, PHP and MySQL",
    Price: 770,
    image: "http://localhost/Main/Assets/Books/WEB/The%20Web%20Book.png",
    description: "The Web Book is a free book that tells you everything you need to know in order to create a home or business Web site from scratch. It covers everything from registering a domain name and renting some hosting space, to creating your first HTML page, to building full online database applications with PHP and MySQL. It also tells you how to market and promote your site, and how to make money from it.",
    Author:"Author :Robert Schifreen"
  },
  "book51": {
    id: "web3", // Added ID
    title: " HTML5 in Action",
    Price: 500,
    image: "http://localhost/Main/Assets/Books/WEB/HTML5%20in%20Action.png",
    description: "HTML5 is not a few new tags and features added to an old standard - it's the foundation of the modern web, enabling its interactive services, single-page UI, interactive games, and complex business applications. With support for standards-driven mobile app development, powerful features like local storage and WebSockets, superb audio and video APIs, and new layout options using CSS3, SVG, and Canvas, HTML5 has entered its prime time.This book provides a complete introduction to web development using HTML5. You'll explore every aspect of the HTML5 specification through real-world examples and code samples. It's much more than just a specification reference, though. It lives up to the name HTML5 in Action by giving you the practical, hands-on guidance you'll need to use key features.",
    Author:"Author :Rob Crowther, Joe Lennon, Ash Blue, and Greg Wanish"
  },
  "book52": {
    id: "web4", // Added ID
    title: "How to Code in HTML5 and CSS3",
    Price: 400,
    image: "http://localhost/Main/Assets/Books/WEB/How%20to%20Code%20in%20HTML5%20and%20CSS3.png",
    description: "This book begins with a hands-on course that teaches you HTML and CSS from scratch, including the latest HTML5 and CSS3 features. This short course ends with a chapter that teaches you how to use fluid design and media queries to implement Responsive Web Design so your pages will look good and work right on any screen, from phone to tablet to desktop.So whether you're a web designer, a JavaScript programmer, a server-side programmer, or a rookie, this book delivers all the HTML and CSS skills that you need on the job.",
    Author:"Author :Damian Wielgosik"
  },
  "book53": {
    id: "web5", // Added ID
    title: "Essential HTML",
    Price: 600,
    image: "http://localhost/Main/Assets/Books/WEB/Essential%20HTML.png",
    description: "This book written to provide clear and concise explanation of topics for programmers both starting to learn the HTML markup language as well as those diving in more complex topics. Most examples are linked to online playground that allows you to change the code and re-run it.",
    Author:"Author :Krzysztof Kowalczyk"
  },
  "book54": {
    id: "web6", // Added ID
    title: "Next Generation HTML5 and JavaScript",
    Price: 300,
    image: "http://localhost/Main/Assets/Books/WEB/Next%20Generation%20HTML5%20and%20JavaScript.png",
    description: "JavaScript is chaotic. The pace of change is faster than ever and it seems like a new framework or important library pops up every couple of weeks. A major shift in the language is about to hit when ECMAScript 6 is finalized this year.Modern web developers have to juggle more constraints than ever before; standing still is not an option. We must drive forward and this eMag is a guide to getting on the right track. We'll hear from developers in the trenches building some of the most advanced web applications and how to apply what they have learned to our own work.",
    Author:"Author :David Pitt"
  },
};
// =================== USER AUTHENTICATION =================== //

// Check login status and toggle login/logout buttons
function checkLoginStatus() {
  const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
  const loginBtn = document.getElementById('login-btn');
  const logoutBtn = document.getElementById('logout-btn');

  if (loginBtn && logoutBtn) {
    if (isLoggedIn) {
      loginBtn.style.display = 'none';   // Hide login button
      logoutBtn.style.display = 'blocks'; // Show logout button
    } else {
      loginBtn.style.display = 'block';  // Show login button
      logoutBtn.style.display = 'none';  // Hide logout button
    }
  }
}
// Redirect to login page
function handleLogin() {
  window.location.href = "http://localhost/Main/Login/Login.html";
  localStorage.setItem('isLoggedIn','true')
}

// Logout the user and redirect to login page
function handleLogout() {
  localStorage.setItem('isLoggedIn', 'false');
  window.location.href = "http://localhost/Main/Login/Login.html";
}



// =================== BOOK POPUP FUNCTIONALITY =================== //

function setupBookPopups() {
  const bookCards = document.querySelectorAll('.book-card');

  bookCards.forEach(card => {
    card.addEventListener('click', function(e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;

      const bookId = this.dataset.bookId;
      const book = books[bookId];

      if (book) {
        document.getElementById('popupBookImage').src = book.image;
        document.getElementById('popupBookTitle').textContent = book.title;
        document.getElementById('popupBookId').textContent = book.id;
        document.getElementById('price').textContent = `Price : ${book.Price}`;
        document.getElementById('popupBookDesc').textContent = book.description;
        document.getElementById('author').textContent = `Author : ${book.Author}`;

        // Show/hide PDF button based on whether book has PDF
        const pdfBtn = document.getElementById('downloadPdfBtn');
        if (book.pdfUrl) {
          pdfBtn.style.display = 'block';
          pdfBtn.onclick = function() {
            downloadPDF(book.pdfUrl, book.title);
          };
        } else {
          pdfBtn.style.display = 'none';
        }

        document.getElementById('bookPopup').style.display = 'flex';
      }
    });
  });

  // Close popup on X click
  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('bookPopup').style.display = 'none';
    });
  }

  // Close popup on outside click
  window.addEventListener('click', event => {
    if (event.target === document.getElementById('bookPopup')) {
      document.getElementById('bookPopup').style.display = 'none';
    }
  });
}

function downloadPDF(pdfUrl, bookTitle) {
  // Create a temporary anchor element to trigger download
  const link = document.createElement('a');
  link.href = pdfUrl;
  link.download = `${bookTitle.replace(/[^a-z0-9]/gi, '_')}.pdf`; // Clean up filename
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  
  // Optional: Track downloads
  console.log(`Downloaded PDF for: ${bookTitle}`);
}

// =================== CART FUNCTIONALITY =================== //

function addToCart(button) {
  const popup = button.closest('.popup-content');
  const priceText = popup.querySelector('#price').textContent;
  const bookTitle = popup.querySelector('#popupBookTitle').textContent.trim();
  
  // Extract book ID from the clicked book
  const bookCard = button.closest('.book-popup').previousElementSibling.querySelector('.book-card[data-book-id]');
  const bookId = bookCard ? bookCard.dataset.bookId : null;
  
  if (!bookId) {
    alert("Could not identify book");
    return;
  }

  // More robust price extraction
  const priceMatch = priceText.match(/(\d+\.?\d*)/);
  if (!priceMatch) {
    alert("Could not determine book price");
    return;
  }
  
  const numericPrice = parseFloat(priceMatch[0]);
  if (isNaN(numericPrice)) {
    alert("Invalid price format");
    return;
  }

  const book = {
    id: bookId,  // Use the actual book ID from data-book-id
    title: bookTitle,
    price: numericPrice,
    quantity: 1,
    image: popup.querySelector('#popupBookImage').src.trim(),
    author: popup.querySelector('#author').textContent.replace('Author : ', '').trim()
  };

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  
  // Check if book already exists in cart using the correct ID

  const exists = cart.find(item => 
    item.id === book.id &&
    item.title === book.title && 
    item.author === book.author
  );
  
  if (exists) {
    alert("Book already in cart!");
    exists.quantity += 1; // Increment quantity
  } else {
    alert("Book added to cart!");
    cart.push(book);
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  
  updateCartCount();
}

// Update cart badge count on cart icon
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartIcons = document.querySelectorAll('.Cart'); // Select all cart icons
  
  cartIcons.forEach(cartIcon => {
    const existingBadge = cartIcon.querySelector('.cart-badge');
    if (existingBadge) existingBadge.remove();

    if (cart.length > 0) {
      const badge = document.createElement('span');
      badge.className = 'cart-badge';
      badge.textContent = cart.reduce((total, item) => total + item.quantity, 0);
      cartIcon.appendChild(badge);
    }
  });
}



// =================== SEARCH FUNCTIONALITY =================== //

function searchBooks() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const bookCards = document.querySelectorAll(".book-card");
  let matchFound = false;

  bookCards.forEach(card => {
    const title = card.querySelector(".Book_link").textContent.toLowerCase();
    if (title.includes(query)) {
      card.style.display = "flex";
      card.classList.add("highlight");
      matchFound = true;
    } else {
      card.style.display = "none";
      card.classList.remove("highlight");
    }
  });

  const noResults = document.getElementById("noResults");
  if (noResults) {
    noResults.style.display = matchFound ? "none" : "block";
  }
}



// =================== IMAGE SLIDER =================== //

function setupImageSlider() {
  const sliderTrack = document.querySelector('.slider-track');
  const slides = document.querySelectorAll('.slide');
  let currentIndex = 0;

  function showSlide(index) {
    const offset = -index * 100;
    sliderTrack.style.transform = `translateX(${offset}%)`;
  }

  function nextSlide() {
    currentIndex = (currentIndex + 1) % slides.length;
    showSlide(currentIndex);
  }

  setInterval(nextSlide, 5000); // Slide every 5 seconds
}


// =================== INIT ON LOAD =================== //

document.addEventListener('DOMContentLoaded', () => {
  checkLoginStatus();
  setupBookPopups();
  updateCartCount();
  setupImageSlider();

  // Event listeners for login/logout
  document.getElementById('login-btn')?.addEventListener('click', handleLogin);
  document.getElementById('logout-btn')?.addEventListener('click', handleLogout);

  // Event listener for cart click
  document.querySelector('.Cart')?.addEventListener('click', () => {
    window.location.href = "http://localhost/Main/cart.html";
  });

  // Search button and enter key
  const searchBtn = document.getElementById("searchBtn");
  const searchInput = document.getElementById("searchInput");

  searchBtn?.addEventListener("click", searchBooks);
  searchInput?.addEventListener("keydown", function(e) {
    if (e.key === "Enter") searchBooks();
  });
});