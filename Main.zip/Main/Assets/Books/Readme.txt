book quantity 
1-10  c
11-19 c++
20-30 java
30-38 python
39-48 PHP
49-   WEB