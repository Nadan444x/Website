// ✅ Book Data
const books = {
  //python books

  "book31": {
    title: "Object-Oriented Programming in Python",
    Price: "Price :500 RS",
    image: "http://localhost/Main/Assets/Books/Python/Object-Oriented%20Programming%20in%20Python.png",
    description: "This book is an intuitive and thorough guide to mastering object-oriented programming from the ground up. You'll cover the basics of building classes and creating objects, and put theory into practice with clear examples that help visualize the object-oriented style.",
    Author:"Author :Michael H. Goldwasser"
  },
  "book32": {
    title: "Introduction to Computer Programming with Python",
    Price: "Price :450 RS",
    image: "http://localhost/Main/Assets/Books/Python/Introduction%20to%20Computer%20Programming%20with%20Python.png",
    description: "This introduction to computer programming with Python begins with some of the basics of computing and programming before diving into the fundamental elements and building blocks of computer programs in Python language. From the installation of Python, Python interactive programming, and integrated development environments to raising and handling exceptions, using compound data types to solve problems, and implement divide-and-conquer processes using functions, classes and modules, this textbook will set students up for success in programming and computing study and practice. The included exercises and projects are designed to hone students’ skills.",
    Author:"Author :Harris Wang"
  },

  "book33": {
    title: "Fundamentals of Python Programming",
    Price: "Price :975 RS",
    image: "http://localhost/Main/Assets/Books/Python/Fundamentals%20of%20Python%20Programming.png",
    description: "his book focuses on introducing programming techniques and developing good habits. To that end, our approach avoids some of the more esoteric features of Python and concentrates on the programming basics that transfer directly to other imperative programming languages.Its easygoing approach is ideal, no matter what your background. The approach starts with simple algorithmic code and then scales into working with functions, objects, and classes as the problems become more complex and require new abstraction mechanisms.",
    Author:"Author :Richard L. Halterman"
  },
  "book34": {
    title: "Python for Software Development",
    Price: "Price :1350 RS",
    image: "http://localhost/Main/Assets/Books/Python/Python%20for%20Software%20Development.png",
    description: "This is a textbook in Python Programming with lots of Examples, Exercises, and Practical Applications within Software Systems, Software Development, Software Engineering, Database Systems, Web Application Desktop Applications, GUI Applications, etc. The focus is on the use of Python for creating modern Software Systems.",
    Author:"Author :Hans-Petter Halvorsen"
  },
  "book35": {
    title: "Internet of Things with Python",
    Price: "Price :350 RS",
    image: "http://localhost/Main/Assets/Books/Python/Internet%20of%20Things%20with%20Python.jpg",
    description: "The book is ideal for Python developers who want to explore the tools in the Python ecosystem in order to build their own IoT applications and work on IoT-related projects. It is also a very useful resource for developers with experience in other programming languages that want to easily prototype IoT applications with the Intel Galileo Gen 2 board.",
    Author:"Author :Gastón C. Hillar"
  },
  "book36": {
    title: "Python Programming",
    Price: "Price :800 RS",
    image: "http://localhost/Main/Assets/Books/Python/Python%20Programming.jpg",
    description: "This is a textbook in Python Programming with lots of Practical Examples and Exercises. You will learn the necessary foundation for basic programming with focus on Python. You’ll also learn some advanced language features that recently have become more common in Python code.",
    Author:"Author :Hans-Petter Halvorsen"
  },
  "book37": {
    title: "Functional Programming in Python",
    Price: "Price :0 RS",
    image: "http://localhost/Main/Assets/Books/Python/Functional%20Programming%20in%20Python.png",
    description: "Python is not a functional programming language, but it is a multi-paradigm language that makes functional programming easy to perform, and easy to mix with other programming styles. In this paper, David Mertz, a director of Python Software Foundation, examines the functional aspects of the language and points out which options work well and which ones you should generally decline.Mertz describes ways to avoid Python's imperative-style flow control, the nuances of callable functions, how to work lazily with iterators, and the use of higher-order functions. He also lists several third-party Python libraries useful for functional programming.",
    Author:"Author :David Mertz"
  },

  "book38": {
    title: "Data Structures and Algorithms in Python",
    Price: "Price :450 RS",
    image: "http://localhost/Main/Assets/Books/Python/Data%20Structures%20and%20Algorithms%20in%20Python.png",
    description: "This textbook offers a comprehensive, definitive introduction to data structures in Python. Designed to provide a comprehensive introduction to data structures and algorithms, including their design, analysis, and implementation using Python.",
    Author:"Author :Michael T. Goodrich, Roberto Tamassia, Michael H. Goldwasser"
  },

};

// ✅ Show Book Popup
function setupBookPopups() {
  const bookCards = document.querySelectorAll('.book-card');
  bookCards.forEach(card => {
    card.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;
      const bookId = this.dataset.bookId;
      const book = books[bookId];
      if (book) {
        document.getElementById('popupBookImage').src = book.image;
        document.getElementById('popupBookTitle').textContent = book.title;
        document.getElementById('price').textContent = book.Price;
        document.getElementById('popupBookDesc').textContent = book.description;
        document.getElementById('author').textContent = book.Author;
        document.getElementById('bookPopup').style.display = 'flex';
      }
    });
  });

  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('bookPopup').style.display = 'none';
    });
  }

  window.addEventListener('click', event => {
    if (event.target === document.getElementById('bookPopup')) {
      document.getElementById('bookPopup').style.display = 'none';
    }
  });
}

// ✅ Add to Cart Functionality
function addToCart(button) {
  const popup = button.closest('.popup-content');
  const book = {
    title: popup.querySelector('#popupBookTitle').textContent.trim(),
    price: popup.querySelector('#price').textContent.replace('Price : ', '').trim(),
    image: popup.querySelector('#popupBookImage').src.trim(),
    author: popup.querySelector('#author').textContent.replace('Author : ', '').trim()
  };

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const exists = cart.some(item => item.title === book.title && item.author === book.author);
  if (!exists) {
    cart.push(book);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Book added to cart!");
    updateCartCount();
  } else {
    alert("This book is already in your cart!");
  }
}

// ✅ Update Cart Count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    const existingBadge = cartIcon.querySelector('.cart-badge');
    if (existingBadge) existingBadge.remove();

    if (cart.length > 0) {
      const badge = document.createElement('span');
      badge.className = 'cart-badge';
      badge.textContent = cart.length;
      cartIcon.appendChild(badge);
    }
  }
}

// ✅ Search Functionality
function searchBooks() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const bookCards = document.querySelectorAll(".book-card");
  let matchFound = false;

  bookCards.forEach(card => {
    const title = card.querySelector(".Book_link").textContent.toLowerCase();
    if (title.includes(query)) {
      card.style.display = "flex";
      card.classList.add("highlight");
      matchFound = true;
    } else {
      card.style.display = "none";
      card.classList.remove("highlight");
    }
  });

  const noResults = document.getElementById("noResults");
  noResults.style.display = matchFound ? "none" : "block";
}

// ✅ Initialize on Load
document.addEventListener('DOMContentLoaded', () => {
  setupBookPopups();
  updateCartCount();

  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    cartIcon.addEventListener('click', () => {
      window.location.href = "http://localhost/Main/cart.html";
    });
  }

  const searchBtn = document.getElementById("searchBtn");
  if (searchBtn) searchBtn.addEventListener("click", searchBooks);

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") searchBooks();
    });
  }
});