// ✅ Book Data
const books = {
  "book20": {
    title: "Programming with Java",
    Price: "Price :800 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Programming%20with%20Java.png",
    description: "This is a beginner-friendly eTextbook that introduces readers to the fundamentals of Java...",
    Author: "Author :Ashik Ahmed Bhuiyan, Md Amiruzzaman"
  },
  "book21": {
    title: "Programming Basics with Java",
    Price: "Price :1300 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Programming%20Basics%20with%20Java.png",
    description: "This guide introduces readers to writing entry-level programming code...",
    Author: "Author : Svetlin Nakov"
  },
  "book22": {
    title: "Programming Problems in Java",
    Price: "Price :400 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Programming%20Problems%20in%20Java.jpg",
    description: "A complete primer for the technical programming interview...",
    Author: "Author :James Wong and Bradley Green"
  },
  "book23": {
    title: "Java for Beginners: A Crash Course",
    Price: "Price :350 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Java%20for%20Beginners%20A%20Crash%20Course.png",
    description: "This book includes a unique project at the end requiring application of all concepts...",
    Author: "Author :Riccardo Flask"
  },
  "book24": {
    title: "Think Java",
    Price: "Price :450 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Think%20Java%20Like%20a%20Computer%20Scientist.jpg",
    description: "Hands-on introduction to computer science and Java programming...",
    Author: "Author :Allen B. Downey, Chris Mayfield"
  },
  "book25": {
    title: "Java 23 Key Concepts in Brief",
    Price: "Price :500 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Java%2023%20Key%20Concepts%20in%20Brief.png",
    description: "A concise guide for Java 23 features for experienced developers...",
    Author: "Author :Sergio Petrucci"
  },
  "book26": {
    title: "Advanced Java Programming",
    Price: "Price :650 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Advanced%20Java%20Programming.jpg",
    description: "Comprehensive coverage with real-world examples and code...",
    Author: "Author :Andriy Redko, Jitendra Patel"
  },
  "book27": {
    title: "Java Based Real Time Programming",
    Price: "Price :770 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Java%20Based%20Real%20Time%20Programming.png",
    description: "Covers concurrency techniques and building high-performance systems...",
    Author: "Author :Klas Nilsson"
  },
  "book28": {
    title: "Java Transaction Design Strategies",
    Price: "Price :1500 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Java%20Transaction%20Design%20Strategies.jpg",
    description: "Master transaction handling using EJB and Spring frameworks...",
    Author: "Author : Mark Richards"
  },
  "book29": {
    title: "Java Application Development on Linux",
    Price: "Price :770 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Java%20Application%20Development%20on%20Linux.jpg",
    description: "Learn how to deploy and manage Java apps on Linux platforms...",
    Author: "Author :Carl Albing, Michael Schwarz"
  },
  "book30": {
    title: "Java in a Nutshell",
    Price: "Price :750 RS",
    image: "http://localhost/Main/Assets/Books/JAVA/Java%20in%20a%20Nutshell%20Desktop%20Quick%20Reference.jpg",
    description: "A modern reference for experienced Java developers covering Java 17...",
    Author: "Author :Benjamin J. Evans, Jason Clark, David Flanagan"
  }
};

// ✅ Show Book Popup
function setupBookPopups() {
  const bookCards = document.querySelectorAll('.book-card');
  bookCards.forEach(card => {
    card.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;
      const bookId = this.dataset.bookId;
      const book = books[bookId];
      if (book) {
        document.getElementById('popupBookImage').src = book.image;
        document.getElementById('popupBookTitle').textContent = book.title;
        document.getElementById('price').textContent = book.Price;
        document.getElementById('popupBookDesc').textContent = book.description;
        document.getElementById('author').textContent = book.Author;
        document.getElementById('bookPopup').style.display = 'flex';
      }
    });
  });

  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('bookPopup').style.display = 'none';
    });
  }

  window.addEventListener('click', event => {
    if (event.target === document.getElementById('bookPopup')) {
      document.getElementById('bookPopup').style.display = 'none';
    }
  });
}

// ✅ Add to Cart Functionality
function addToCart(button) {
  const popup = button.closest('.popup-content');
  const book = {
    title: popup.querySelector('#popupBookTitle').textContent.trim(),
    price: popup.querySelector('#price').textContent.replace('Price : ', '').trim(),
    image: popup.querySelector('#popupBookImage').src.trim(),
    author: popup.querySelector('#author').textContent.replace('Author : ', '').trim()
  };

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const exists = cart.some(item => item.title === book.title && item.author === book.author);
  if (!exists) {
    cart.push(book);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Book added to cart!");
    updateCartCount();
  } else {
    alert("This book is already in your cart!");
  }
}

// ✅ Update Cart Count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    const existingBadge = cartIcon.querySelector('.cart-badge');
    if (existingBadge) existingBadge.remove();

    if (cart.length > 0) {
      const badge = document.createElement('span');
      badge.className = 'cart-badge';
      badge.textContent = cart.length;
      cartIcon.appendChild(badge);
    }
  }
}

// ✅ Search Functionality
function searchBooks() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const bookCards = document.querySelectorAll(".book-card");
  let matchFound = false;

  bookCards.forEach(card => {
    const title = card.querySelector(".Book_link").textContent.toLowerCase();
    if (title.includes(query)) {
      card.style.display = "flex";
      card.classList.add("highlight");
      matchFound = true;
    } else {
      card.style.display = "none";
      card.classList.remove("highlight");
    }
  });

  const noResults = document.getElementById("noResults");
  noResults.style.display = matchFound ? "none" : "block";
}

// ✅ Initialize on Load
document.addEventListener('DOMContentLoaded', () => {
  setupBookPopups();
  updateCartCount();

  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    cartIcon.addEventListener('click', () => {
      window.location.href = "http://localhost/Main/cart.html";
    });
  }

  const searchBtn = document.getElementById("searchBtn");
  if (searchBtn) searchBtn.addEventListener("click", searchBooks);

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") searchBooks();
    });
  }
});