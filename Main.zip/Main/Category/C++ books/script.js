// ✅ Book Data
const books = {
 "book11": {
        title: "Data Structures and Algorithm Analysis in C++, Third Edition",
        Price: "Price :2726 RS",
        image: "http://localhost/Main/Assets/Books/C++/Data%20Structures%20and%20Algorithm%20Analysis%20in%20C.jpg",
        description: "A comprehensive treatment focusing on the creation of efficient data structures and algorithms, this text explains how to select or design the data structure best suited to specific problems. It uses C++ as the programming language and is suitable for second-year data structure courses and computer science courses in algorithmic analysis.",
        Author:"Author :Clifford A. Shaffer"
      },
      "book12": {
        title: "Fundamentals of Programming C++",
        Price: "Price :1500 RS",
        image: "http://localhost/Main/Assets/Books/C++/Fundamentals%20of%20Programming%20C++.png",
        description: "This book teaches the basics of C++ programming in an easy-to-follow style, without assuming previous experience in any other language. A variety of examples such as game programming, club membership organization, grade tracking and grade point average calculation, make learning C++ both fun and practical. Each chapter contains at least one complete, fully functional example program, with several smaller examples provided throughout the book.",
        Author:"Author :Richard L. Halterman"
      },
      
      "book13": {
        title: "Data Parallel C++, 2nd Edition: Programming Accelerated Systems Using C++ ",
        Price: "Price :1500 RS",
        image: "http://localhost/Main/Assets/Books/C++/Data%20Parallel%20C++.jpg",
        description: "Learn how to accelerate C++ programs using Data Parallelism and SYCL.This open access book enables C++ programmers to be at the forefront of this exciting and important development that is helping to push computing to new levels. This updated second edition is full of practical advice, detailed explanations, and code examples to illustrate key topics.",
        Author:"Author :James Reinders, Ben Ashbaugh, James Brodman, Michael Kinsner, John Pennycook, Xinmin Tian"
      },
      "book14": {
        title: "Modern C++ Tutorial",
        Price: "Price :350 RS",
        image: "http://localhost/Main/Assets/Books/C++/Modern%20C++%20Tutorial.png",
        description: "The book claims to be On The Fly. Its intent is to provide a comprehensive introduction to the relevant features regarding modern C++ (before 2020s). Readers can choose interesting content according to the following table of content to learn and quickly familiarize the new features you would like to learn. Readers should be aware that not all of these features are required. Instead, it should be learned when you really need it.",
        Author:"Author : Changkun Ou"
      },
      "book15": {
        title: "C++ Programming",
        Price: "Price :750 RS",
        image: "http://localhost/Main/Assets/Books/C++/C++%20Programming.png",
        description: "This book covers the C++ programming language, its interactions with software design and real life use of the language. It is presented in a series of chapters as an introductory prior to advance courses but can also be used as a reference book.",
        Author:"Author : Wikibooks Contributors"
      },
      "book16": {
        title: "Jumping into C++",
        Price: "Price :2300 RS",
        image: "http://localhost/Main/Assets/Books/C++/Jumping%20into%20C++.jpg",
        description: "As a professional C++ developer and former Harvard teaching fellow, I know what you need to know to be a great C++ programmer, and I know how to teach it, one step at a time. I know where people struggle, and why, and how to make it clear.",
        Author:"Author : Alex Allain"
      },
      "book17": {
        title: "Modern C++ Programming Techniques for Scientific Computing",
        Price: "Price :700 RS",
        image: "http://localhost/Main/Assets/Books/C++/Modern%20C++%20Programming.png",
        description: "This easy-to-read textbook/reference presents a comprehensive introduction to scientific programming techniques in C++. With a practical focus on learning by example, the theory is supported by numerous exercises.",
        Author:"Author :Ole Klein"
      },
      "book18": {
        title: "A Complete Guide to Programming in C++",
        Price: "Price :900 RS",
        image: "http://localhost/Main/Assets/Books/C++/A%20Complete%20Guide%20to%20Programming%20in%20C++.jpg",
        description: "This book was written for both students interested in learning the C++ programming language from scratch, and for advanced C++ programmers wishing to enhance their knowledge of C++.The chapters are organized to guide the reader from elementary language concepts to professional software development, with in-depth coverage of all the C++ language elements 'en route.The order in which these elements are discussed reflects the goal of helping students create useful programs every step of the way.",
        Author:"Author :Ulla Kirch-Prinz, Peter Prinz"
      },
      "book19": {
        title: " Learn C++ - Simply Easy Learning",
        Price: "Price :400 RS",
        image: "http://localhost/Main/Assets/Books/C++/Learn%20C++.png",
        description: "C++ is a middle-level programming language developed by Bjarne Stroustrup starting in 1979 at Bell Labs. C++ runs on a variety of platforms, such as Windows, Mac OS, and the various versions of UNIX.This book adopts a simple and practical approach to describe the concepts of C++. It has been prepared for the beginners to help them understand the basic to advanced concepts related to C++.",
        Author:"Author :Tutorials Point"
      },

};

// ✅ Show Book Popup
function setupBookPopups() {
  const bookCards = document.querySelectorAll('.book-card');

  bookCards.forEach(card => {
    card.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;

      const bookId = this.dataset.bookId;
      const book = books[bookId];

      if (book) {
        document.getElementById('popupBookImage').src = book.image;
        document.getElementById('popupBookTitle').textContent = book.title;
        document.getElementById('price').textContent = book.Price;
        document.getElementById('popupBookDesc').textContent = book.description;
        document.getElementById('author').textContent = book.Author;

        document.getElementById('bookPopup').style.display = 'flex';
      }
    });
  });

  // Close popup
  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', function () {
      document.getElementById('bookPopup').style.display = 'none';
    });
  }

  window.addEventListener('click', function (event) {
    if (event.target === document.getElementById('bookPopup')) {
      document.getElementById('bookPopup').style.display = 'none';
    }
  });
}

// ✅ Add to Cart Functionality
function addToCart(button) {
  const popup = button.closest('.popup-content');
  const book = {
    title: popup.querySelector('#popupBookTitle').textContent.trim(),
    price: popup.querySelector('#price').textContent.replace('Price : ', '').trim(),
    image: popup.querySelector('#popupBookImage').src.trim(),
    author: popup.querySelector('#author').textContent.replace('Author : ', '').trim()
  };

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const exists = cart.some(item => item.title === book.title && item.author === book.author);

  if (!exists) {
    cart.push(book);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Book added to cart!");
    updateCartCount();
  } else {
    alert("This book is already in your cart!");
  }
}

// ✅ Update Cart Icon Count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartIcon = document.querySelector('.Cart');

  if (cartIcon) {
    const existingBadge = cartIcon.querySelector('.cart-badge');
    if (existingBadge) existingBadge.remove();

    if (cart.length > 0) {
      const badge = document.createElement('span');
      badge.className = 'cart-badge';
      badge.textContent = cart.length;
      cartIcon.appendChild(badge);
    }
  }
}

// ✅ Search Functionality
function searchBooks() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const bookCards = document.querySelectorAll(".book-card");
  let matchFound = false;

  bookCards.forEach(card => {
    const title = card.querySelector(".Book_link").textContent.toLowerCase();
    if (title.includes(query)) {
      card.style.display = "flex";
      card.classList.add("highlight");
      matchFound = true;
    } else {
      card.style.display = "none";
      card.classList.remove("highlight");
    }
  });

  const noResults = document.getElementById("noResults");
  if (noResults) {
    noResults.style.display = matchFound ? "none" : "block";
  }
}

// ✅ Initialization
document.addEventListener('DOMContentLoaded', function () {
  setupBookPopups();
  updateCartCount();

  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    cartIcon.addEventListener('click', () => {
      window.location.href = "http://localhost/Main/cart.html";
    });
  }

  const searchBtn = document.getElementById("searchBtn");
  if (searchBtn) {
    searchBtn.addEventListener("click", searchBooks);
  }

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") searchBooks();
    });
  }
});
