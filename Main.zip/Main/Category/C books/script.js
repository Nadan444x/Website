// ✅ Book Data
const books = {
  book1: {
    title: "Modern Approach to C Programming",
    Price: "Price : 780 RS",
    image: "http://localhost/Main/Assets/Books/C/c.webp",
    description: "This book provides a comprehensive guide to C programming, starting with the fundamentals of the C language and progressing to advanced topics",
    Author: "Author : Amisha Saxena, Dr. Nancy Arya, Anil Tanwar"
  },
  book2: {
    title: "Modern C",
    Price: "Price : 500 RS",
    image: "http://localhost/Main/Assets/Books/C/ModernC.jpg",
    description: "Modern C focuses on the new and unique features of modern C programming based on the latest C standards.",
    Author: "Author : Jens Gustedt"
  },
  book3: {
    title: "C In Depth",
    Price: "Price : 415 RS",
    image: "http://localhost/Main/Assets/Books/C/CDepth.jpg",
    description: "A simple and easy-to-understand book for both beginner and advanced programmers.",
    Author: "Author : S.K.Srivastava / Deepali Srivastava"
  },
  book4: {
    title: "Expert C Programming",
    Price: "Price : 2000 RS",
    image: "http://localhost/Main/Assets/Books/C/Expert%20C%20Programming.jpg",
    description: "For experienced C programmers wanting to master the fine arts of ANSI C.",
    Author: "Author : Peter van der Linden"
  },
  book5: {
    title: "Beej's Guide to C Programming",
    Price: "Price : 1500 RS",
    image: "http://localhost/Main/Assets/Books/C/BeejC.png",
    description: "A great book for beginners and curious computer users who want to know how things work behind the scenes.",
    Author: "Author : Brian (Beej Jorgensen) Hall"
  },
  book6: {
    title: "Extreme C",
    Price: "Price : 3300 RS",
    image: "http://localhost/Main/Assets/Books/C/Extreme%20C.jpg",
    description: "Master advanced capabilities of C with this practical guide to preprocessor directives, macros, pointers, and more.",
    Author: "Author : Kamran Amini"
  },
  book7: {
    title: "A Book on C: Programming in C",
    Price: "Price : 500 RS",
    image: "http://localhost/Main/Assets/Books/C/Book%20on%20C.jpg",
    description: "Step-by-step dissections of program code and thorough exercises. Great for grasping ADTs, recursion, and multifile programming.",
    Author: "Author : Al Kelley, and Ira Pohl"
  },
  book8: {
    title: "The C Book: Featuring the ANSI C Standard",
    Price: "Price : 700 RS",
    image: "http://localhost/Main/Assets/Books/C/The%20C%20Book.jpg",
    description: "Structured introduction to ANSI C for experienced high-level programmers.",
    Author: "Author : Mike Banahan, Declan Brady, Mark Doran"
  },
  book9: {
    title: "Object Oriented Programming with ANSI-C",
    Price: "Price : 1500 RS",
    image: "http://localhost/Main/Assets/Books/C/Object%20Oriented%20Programming%20with%20ANSI-C.jpg",
    description: "Demystifies OOP concepts using ANSI-C in a logical, practical way.",
    Author: "Author : E. Balagurusamy"
  },
  book10: {
    title: "Programming In Ansi C",
    Price: "Price : 0 RS",
    image: "http://localhost/Main/Assets/Books/C/Programming%20In%20Ansi%20C.png",
    description: "Ideal for beginners, covering basic to intermediate C programming concepts.",
    Author: "Author : Ray Dawson"
  }
};

// ✅ Show Book Popup
function setupBookPopups() {
  const bookCards = document.querySelectorAll('.book-card');

  bookCards.forEach(card => {
    card.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;

      const bookId = this.dataset.bookId;
      const book = books[bookId];

      if (book) {
        document.getElementById('popupBookImage').src = book.image;
        document.getElementById('popupBookTitle').textContent = book.title;
        document.getElementById('price').textContent = book.Price;
        document.getElementById('popupBookDesc').textContent = book.description;
        document.getElementById('author').textContent = book.Author;

        document.getElementById('bookPopup').style.display = 'flex';
      }
    });
  });

  // Close popup
  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', function () {
      document.getElementById('bookPopup').style.display = 'none';
    });
  }

  window.addEventListener('click', function (event) {
    if (event.target === document.getElementById('bookPopup')) {
      document.getElementById('bookPopup').style.display = 'none';
    }
  });
}

// ✅ Add to Cart Functionality
function addToCart(button) {
  const popup = button.closest('.popup-content');
  const book = {
    title: popup.querySelector('#popupBookTitle').textContent.trim(),
    price: popup.querySelector('#price').textContent.replace('Price : ', '').trim(),
    image: popup.querySelector('#popupBookImage').src.trim(),
    author: popup.querySelector('#author').textContent.replace('Author : ', '').trim()
  };

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const exists = cart.some(item => item.title === book.title && item.author === book.author);

  if (!exists) {
    cart.push(book);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Book added to cart!");
    updateCartCount();
  } else {
    alert("This book is already in your cart!");
  }
}

// ✅ Update Cart Icon Count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartIcon = document.querySelector('.Cart');

  if (cartIcon) {
    const existingBadge = cartIcon.querySelector('.cart-badge');
    if (existingBadge) existingBadge.remove();

    if (cart.length > 0) {
      const badge = document.createElement('span');
      badge.className = 'cart-badge';
      badge.textContent = cart.length;
      cartIcon.appendChild(badge);
    }
  }
}

// ✅ Search Functionality
function searchBooks() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const bookCards = document.querySelectorAll(".book-card");
  let matchFound = false;

  bookCards.forEach(card => {
    const title = card.querySelector(".Book_link").textContent.toLowerCase();
    if (title.includes(query)) {
      card.style.display = "flex";
      card.classList.add("highlight");
      matchFound = true;
    } else {
      card.style.display = "none";
      card.classList.remove("highlight");
    }
  });

  const noResults = document.getElementById("noResults");
  if (noResults) {
    noResults.style.display = matchFound ? "none" : "block";
  }
}

// ✅ Initialization
document.addEventListener('DOMContentLoaded', function () {
  setupBookPopups();
  updateCartCount();

  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    cartIcon.addEventListener('click', () => {
      window.location.href = "http://localhost/Main/cart.html";
    });
  }

  const searchBtn = document.getElementById("searchBtn");
  if (searchBtn) {
    searchBtn.addEventListener("click", searchBooks);
  }

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") searchBooks();
    });
  }
});
