// ✅ Book Data
const books = {
  //Web
  "book49": {
    title: "How To Build a Website With CSS and HTML",
    Price: "Price :500 RS",
    image: "http://localhost/Main/Assets/Books/WEB/How%20To%20Build%20a%20Website%20With%20CSS%20and%20HTML.png",
    description: "This project-based eBook will introduce you to Cascading Style Sheets (CSS), a stylesheet language used to control the presentation of websites, by building a personal website using our demonstration site as a model. Though our demonstration site features Sammy the Shark, you can switch out Sammy’s information with your own if you wish to personalize your site.",
    Author:"Author : Erin Glass"
  },
  "book50": {
    title: "The Web Book: The ultimate beginner's guide to HTML, CSS, JavaScript, PHP and MySQL",
    Price: "Price :770 RS",
    image: "http://localhost/Main/Assets/Books/WEB/The%20Web%20Book.png",
    description: "The Web Book is a free book that tells you everything you need to know in order to create a home or business Web site from scratch. It covers everything from registering a domain name and renting some hosting space, to creating your first HTML page, to building full online database applications with PHP and MySQL. It also tells you how to market and promote your site, and how to make money from it.",
    Author:"Author :Robert Schifreen"
  },
  "book51": {
    title: " HTML5 in Action",
    Price: "Price :500 RS",
    image: "http://localhost/Main/Assets/Books/WEB/HTML5%20in%20Action.png",
    description: "HTML5 is not a few new tags and features added to an old standard - it's the foundation of the modern web, enabling its interactive services, single-page UI, interactive games, and complex business applications. With support for standards-driven mobile app development, powerful features like local storage and WebSockets, superb audio and video APIs, and new layout options using CSS3, SVG, and Canvas, HTML5 has entered its prime time.This book provides a complete introduction to web development using HTML5. You'll explore every aspect of the HTML5 specification through real-world examples and code samples. It's much more than just a specification reference, though. It lives up to the name HTML5 in Action by giving you the practical, hands-on guidance you'll need to use key features.",
    Author:"Author :Rob Crowther, Joe Lennon, Ash Blue, and Greg Wanish"
  },
  "book52": {
    title: "How to Code in HTML5 and CSS3",
    Price: "Price :400 RS",
    image: "http://localhost/Main/Assets/Books/WEB/How%20to%20Code%20in%20HTML5%20and%20CSS3.png",
    description: "This book begins with a hands-on course that teaches you HTML and CSS from scratch, including the latest HTML5 and CSS3 features. This short course ends with a chapter that teaches you how to use fluid design and media queries to implement Responsive Web Design so your pages will look good and work right on any screen, from phone to tablet to desktop.So whether you're a web designer, a JavaScript programmer, a server-side programmer, or a rookie, this book delivers all the HTML and CSS skills that you need on the job.",
    Author:"Author :Damian Wielgosik"
  },
  "book53": {
    title: "Essential HTML",
    Price: "Price :600 RS",
    image: "http://localhost/Main/Assets/Books/WEB/Essential%20HTML.png",
    description: "This book written to provide clear and concise explanation of topics for programmers both starting to learn the HTML markup language as well as those diving in more complex topics. Most examples are linked to online playground that allows you to change the code and re-run it.",
    Author:"Author :Krzysztof Kowalczyk"
  },
  "book54": {
    title: "Next Generation HTML5 and JavaScript",
    Price: "Price :300 RS",
    image: "http://localhost/Main/Assets/Books/WEB/Next%20Generation%20HTML5%20and%20JavaScript.png",
    description: "JavaScript is chaotic. The pace of change is faster than ever and it seems like a new framework or important library pops up every couple of weeks. A major shift in the language is about to hit when ECMAScript 6 is finalized this year.Modern web developers have to juggle more constraints than ever before; standing still is not an option. We must drive forward and this eMag is a guide to getting on the right track. We'll hear from developers in the trenches building some of the most advanced web applications and how to apply what they have learned to our own work.",
    Author:"Author :David Pitt"
  },

  "book55": {
    title: "JavaScript: The First 20 Years",
    Price: "Price :500 RS",
    image: "http://localhost/Main/Assets/Books/WEB/JavaScript%20The%20First%2020%20Years.png",
    description: "JavaScript is everywhere, and it has been ranked the most commonly used programming language. There's often some confusion about the two, but JavaScript and Java have almost nothing in common.How a sidekick scripting language for Java, created at Netscape in a ten-day hack, ships first as a de facto Web standard and eventually becomes the world's most widely used programming language.This book tells the story of the creation, design, evolution, and standardization of the JavaScript language over the period of 1995–2015. But the story is not only about the technical details of the language.",
    Author:"Author :Allen Wirfs-Brock and Brendan Eich"
  },
  "book56": {
    title: "Deep JavaScript: Theory and Techniques",
    Price: "Price :450 RS",
    image: "http://localhost/Main/Assets/Books/WEB/Deep%20JavaScript%20Theory%20and%20Techniques.png",
    description: "In depth knowledge of JavaScript makes it easier to learn a variety of other frameworks, including Node.js, React, Angular, and related tools and libraries. This book is designed to help you cover the core JavaScript concepts you need to build modern applications.",
    Author:"Author :Axel Rauschmayer"
  },
  "book57": {
    title: "JavaScript Simplified",
    Price: "Price :770 RS",
    image: "http://localhost/Main/Assets/Books/WEB/JavaScript%20Simplified.png",
    description: "This book begins by teaching you the JavaScript language from the ground up. Then it takes you beyond the fundamentals, so you understand and learn to use advanced programming features.Youre making a smart move to learn JavaScript, the world's most popular computer language. Now you've found a smart way to learn it.",
    Author:"Author :Taye Abidakun"
  },
  "book58": {
    title: "Essential CSS",
    Price: "Price :440 RS",
    image: "http://localhost/Main/Assets/Books/WEB/Essential%20CSS.png",
    description: "This book written to provide clear and concise explanation of topics for programmers both starting to learn the Cascading Style Sheets (CSS) as well as those diving in more complex topics. Most examples are linked to online playground that allows you to change the code and re-run it.You can also quickly navigate to desired content using table of content on the left and search at the top (tip: you can navigate search using only a keyboard with '/' shortcut to start a search).",
    Author:"Author :Krzysztof Kowalczyk"
  },
  "book59": {
    title: "The CSS Handbook",
    Price: "Price :900 RS",
    image: "http://localhost/Main/Assets/Books/WEB/The%20CSS%20Handbook.png",
    description: "This book to help you quickly learn CSS and get familiar with the advanced CSS topics. It is aimed at a vast audience, from beginners to professionals. It talks exclusively about styling HTML documents, although CSS can be used to style other things too.",
    Author:"Author :Flavio Copes"
  },
  "book60": {
    title: "The Magic of CSS",
    Price: "Price :600 RS",
    image: "http://localhost/Main/Assets/Books/WEB/The%20Magic%20of%20CSS.png",
    description: "The material in this textbook is intermediate-to-advanced. It assumes an understanding of the CSS syntax, cascading and inheritance, and commonly used selectors. It also assumes you’ve had enough experience with CSS to have learned not to make these common mistakes anymore.",
    Author:"Author :Adam Schwartz"
  },
};

// ✅ Show Book Popup
function setupBookPopups() {
  const bookCards = document.querySelectorAll('.book-card');
  bookCards.forEach(card => {
    card.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;
      const bookId = this.dataset.bookId;
      const book = books[bookId];
      if (book) {
        document.getElementById('popupBookImage').src = book.image;
        document.getElementById('popupBookTitle').textContent = book.title;
        document.getElementById('price').textContent = book.Price;
        document.getElementById('popupBookDesc').textContent = book.description;
        document.getElementById('author').textContent = book.Author;
        document.getElementById('bookPopup').style.display = 'flex';
      }
    });
  });

  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('bookPopup').style.display = 'none';
    });
  }

  window.addEventListener('click', event => {
    if (event.target === document.getElementById('bookPopup')) {
      document.getElementById('bookPopup').style.display = 'none';
    }
  });
}

// ✅ Add to Cart Functionality
function addToCart(button) {
  const popup = button.closest('.popup-content');
  const book = {
    title: popup.querySelector('#popupBookTitle').textContent.trim(),
    price: popup.querySelector('#price').textContent.replace('Price : ', '').trim(),
    image: popup.querySelector('#popupBookImage').src.trim(),
    author: popup.querySelector('#author').textContent.replace('Author : ', '').trim()
  };

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const exists = cart.some(item => item.title === book.title && item.author === book.author);
  if (!exists) {
    cart.push(book);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Book added to cart!");
    updateCartCount();
  } else {
    alert("This book is already in your cart!");
  }
}

// ✅ Update Cart Count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    const existingBadge = cartIcon.querySelector('.cart-badge');
    if (existingBadge) existingBadge.remove();

    if (cart.length > 0) {
      const badge = document.createElement('span');
      badge.className = 'cart-badge';
      badge.textContent = cart.length;
      cartIcon.appendChild(badge);
    }
  }
}

// ✅ Search Functionality
function searchBooks() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const bookCards = document.querySelectorAll(".book-card");
  let matchFound = false;

  bookCards.forEach(card => {
    const title = card.querySelector(".Book_link").textContent.toLowerCase();
    if (title.includes(query)) {
      card.style.display = "flex";
      card.classList.add("highlight");
      matchFound = true;
    } else {
      card.style.display = "none";
      card.classList.remove("highlight");
    }
  });

  const noResults = document.getElementById("noResults");
  noResults.style.display = matchFound ? "none" : "block";
}

// ✅ Initialize on Load
document.addEventListener('DOMContentLoaded', () => {
  setupBookPopups();
  updateCartCount();

  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    cartIcon.addEventListener('click', () => {
      window.location.href = "http://localhost/Main/cart.html";
    });
  }

  const searchBtn = document.getElementById("searchBtn");
  if (searchBtn) searchBtn.addEventListener("click", searchBooks);

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") searchBooks();
    });
  }
});