// ✅ Book Data
const books = {
  //php books
  "book39": {
    title: "Practical PHP: The Definitive Guide to Programming PHP",
    Price: "Price :600 RS",
    image: "http://localhost/Main/Assets/Books/Php/Practical%20PHP%20The%20Definitive%20Guide%20to%20Programming%20PHP.png",
    description: "This book was written with the goal of making the task of learning PHP something fun that you don't have to worry about. As such, you'll find lots of information for newcomers, even those who haven't programmed much before.On the other end of the scale, this book is packed with lots of information on advanced functionality in PHP if you are a veteran user looking to take your PHP skills above and beyond where they are right now, you will find there is lots to be had here.The goal for this book has been to produce something you can read in whatever order you want. This book assumes no PHP programming skill at all: you'll be taught from scratch in that respect. However, once you have the basics down, you're encouraged to flick through the table of contents, find something that interests you most, and start reading from there.",
    Author:"Author :Paul Hudson"
  },

  "book40": {
    title: "The PHP Programming Language",
    Price: "Price :770 RS",
    image: "http://localhost/Main/Assets/Books/Php/The%20PHP%20Programming%20Language.png",
    description: "This book is a beginner's guide for writing PHP programs from scratch and learning practical programming skills to use with any language. This website is a treasure trove of knowledge and a great platform to enhance your PHP skills.",
    Author:"Author :CodeAhoy"
  },
  "book41": {
    title: "PHP Essentials",
    Price: "Price :320 RS",
    image: "http://localhost/Main/Assets/Books/Php/PHP%20Essentials.png",
    description: "The book is intended to cover all aspects of PHP. It starts by covering the history of PHP before providing a high level overview of how PHP works and why it is so useful to web developers. It then moves on to cover each area of PHP in detail, from the basics of the scripting language through to object oriented programming, file and file system handling and MySQL and SQLite database integration. In addition, chapters are also provided covering the creation and handling of HTML based forms and maintaining state using both cookies and PHP sessions. Each topic area is accompanied by extensive real world examples intended to bring theory to life.",
    Author:"Author :Neil Smyth"
  },
  "book42": {
    title: "PHP Power Programming",
    Price: "Price :450 RS",
    image: "http://localhost/Main/Assets/Books/Php/PHP%20Power%20Programming.jpg",
    description: "This book shows you how to make the most of PHP's industrial-strength enhancements in any project -- no matter how large or complex. Its unique insights and realistic examples illuminate PHP's new object model, powerful design patterns, improved XML Web services support, and much more. Whether you're creating web applications, extensions, packages, or shell scripts, or migrating old code - here are high-powered solutions you won't find anywhere else.",
    Author:"Author :Andi Gutmans, Stig S. Bakken, and Derick Rethans"
  },

  "book43": {
    title: "Essential PHP",
    Price: "Price :300 RS",
    image: "http://localhost/Main/Assets/Books/Php/Essential%20PHP.png",
    description: "This book written to provide clear and concise explanation of topics for programmers both starting to learn the PHP programming as well as those diving in more complex topics. Most examples are linked to online playground that allows you to change the code and re-run it.You can also quickly navigate to desired content using table of content on the left and search at the top (tip: you can navigate search using only a keyboard with '/' shortcut to start a search).",
    Author:"Author :Krzysztof Kowalczyk"
  },
  "book44": {
    title: "PHP: The Right Way",
    Price: "Price :1500 RS",
    image: "http://localhost/Main/Assets/Books/Php/PHP%20The%20Right%20Way.png",
    description: "There is no canonical way to use PHP. This book aims to introduce new PHP developers to some topics which they may not discover until it is too late, and aims to give seasoned pros some fresh ideas on those topics they've been doing for years without ever reconsidering. This ebook will also not tell you which tools to use, but instead offer suggestions for multiple options, when possible explaining the differences in approach and use-case.",
    Author:"Author :Phil Sturgeon and Josh Lockhart"
  },
  "book45": {
    title: "PHP Programming - A Comprehensive Guide to Programming in PHP",
    Price: "Price :450 RS",
    image: "http://localhost/Main/Assets/Books/Php/PHP%20Programming%20A%20Comprehensive%20Guide%20to%20Programming%20in%20PHP.png",
    description: "You will learn PHP programming language by understanding how its primary functions work, how it interacts with HTML, and how its nature of being a server-side scripting language differs from a client-side language, such as JavaScript.",
    Author:"Author :Penn Wu"
  },
  "book46": {
    title: "PHP 101: PHP For the Absolute Beginner",
    Price: "Price :750 RS",
    image: "http://localhost/Main/Assets/Books/Php/PHP%20101%20PHP%20For%20the%20Absolute%20Beginner.png",
    description: "PHP can be used to develop web pages, or even web apps. PHP is widely used with other languages such as HTML, CSS, Ajax and XML, so the learning doesn't stop here!This book caters for the absolute beginners to the intermediate and advanced PHP developers. It takes you through from what is a variable to a nice snippet the author found on backing up a databases or their individual individual tables and emailing them out.",
    Author:"Author : Vikram Vaswani"
  },
  "book47": {
    title: "Upgrading to PHP 7",
    Price: "Price :600 RS",
    image: "http://localhost/Main/Assets/Books/Php/Upgrading%20to%20PHP%207.png",
    description: "PHP 7 - the most dramatic update to the language in over a decade—has arrived. This O'Reilly report provides you with a short guide to the major changes in this new release, including a revamped engine (Zend Engine 3), a bunch of new features, and lots of language cleanup. You’ll learn about basic language changes, deprecated features, Unicode enhancements, changes in Object-Oriented programming, and other enhancements.",
    Author:"Author :Davey Shafik"
  },
  "book48": {
    title: "PHP Pandas: The PHP Programming Language for Everyone",
    Price: "Price :490 RS",
    image: "http://localhost/Main/Assets/Books/Php/PHP%20Pandas%20The%20PHP%20Programming%20Language%20for%20Everyone.png",
    description: "This book is for newcomers to programming and experienced developers alike. Now's the time to learn PHP, and to do so while having fun! Do you like pandas? What are you waiting for It aims to teach everyone how to be a web developer. You don't need any existing web development experience. The entire book is available online to encourage learningWith this practical guide, you'll learn how PHP has become a full-featured, mature language with object-orientation, namespaces, and a growing collection of reusable component libraries.",
    Author:"Author :Dayle Rees"
  },

};

// ✅ Show Book Popup
function setupBookPopups() {
  const bookCards = document.querySelectorAll('.book-card');
  bookCards.forEach(card => {
    card.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON') return;
      const bookId = this.dataset.bookId;
      const book = books[bookId];
      if (book) {
        document.getElementById('popupBookImage').src = book.image;
        document.getElementById('popupBookTitle').textContent = book.title;
        document.getElementById('price').textContent = book.Price;
        document.getElementById('popupBookDesc').textContent = book.description;
        document.getElementById('author').textContent = book.Author;
        document.getElementById('bookPopup').style.display = 'flex';
      }
    });
  });

  const closeBtn = document.querySelector('.close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => {
      document.getElementById('bookPopup').style.display = 'none';
    });
  }

  window.addEventListener('click', event => {
    if (event.target === document.getElementById('bookPopup')) {
      document.getElementById('bookPopup').style.display = 'none';
    }
  });
}

// ✅ Add to Cart Functionality
function addToCart(button) {
  const popup = button.closest('.popup-content');
  const book = {
    title: popup.querySelector('#popupBookTitle').textContent.trim(),
    price: popup.querySelector('#price').textContent.replace('Price : ', '').trim(),
    image: popup.querySelector('#popupBookImage').src.trim(),
    author: popup.querySelector('#author').textContent.replace('Author : ', '').trim()
  };

  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  const exists = cart.some(item => item.title === book.title && item.author === book.author);
  if (!exists) {
    cart.push(book);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("Book added to cart!");
    updateCartCount();
  } else {
    alert("This book is already in your cart!");
  }
}

// ✅ Update Cart Count
function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    const existingBadge = cartIcon.querySelector('.cart-badge');
    if (existingBadge) existingBadge.remove();

    if (cart.length > 0) {
      const badge = document.createElement('span');
      badge.className = 'cart-badge';
      badge.textContent = cart.length;
      cartIcon.appendChild(badge);
    }
  }
}

// ✅ Search Functionality
function searchBooks() {
  const query = document.getElementById("searchInput").value.toLowerCase().trim();
  const bookCards = document.querySelectorAll(".book-card");
  let matchFound = false;

  bookCards.forEach(card => {
    const title = card.querySelector(".Book_link").textContent.toLowerCase();
    if (title.includes(query)) {
      card.style.display = "flex";
      card.classList.add("highlight");
      matchFound = true;
    } else {
      card.style.display = "none";
      card.classList.remove("highlight");
    }
  });

  const noResults = document.getElementById("noResults");
  noResults.style.display = matchFound ? "none" : "block";
}

// ✅ Initialize on Load
document.addEventListener('DOMContentLoaded', () => {
  setupBookPopups();
  updateCartCount();

  const cartIcon = document.querySelector('.Cart');
  if (cartIcon) {
    cartIcon.addEventListener('click', () => {
      window.location.href = "http://localhost/Main/cart.html";
    });
  }

  const searchBtn = document.getElementById("searchBtn");
  if (searchBtn) searchBtn.addEventListener("click", searchBooks);

  const searchInput = document.getElementById("searchInput");
  if (searchInput) {
    searchInput.addEventListener("keydown", function (e) {
      if (e.key === "Enter") searchBooks();
    });
  }
});