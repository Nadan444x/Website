<?php
session_start();

// Database connection
$host = "localhost";
$dbUsername = "root";
$dbPassword = "Rohit@444";
$dbName = "website";

$conn = new mysqli($host, $dbUsername, $dbPassword, $dbName);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$Email1 = $_POST['Email'];
$Password1 = $_POST['Password'];

// Fetch user from the database
$stmt = $conn->prepare("SELECT * FROM registration_data WHERE Email = ?");
$stmt->bind_param("s", $Email1);
$stmt->execute();
$stmt_result = $stmt->get_result();

if($stmt_result->num_rows > 0) {
    $data = $stmt_result->fetch_assoc();
    if($data['Password'] === $Password1) {
        // Set session variables
        $_SESSION['user_id'] = $data['Email']; // Using Email as unique identifier
        
        echo '<script>
            localStorage.setItem("isLoggedIn", "true");
            localStorage.setItem("currentUserId", "'.htmlspecialchars($data['Email']).'");
            localStorage.setItem("username", "'.htmlspecialchars($data['Name']).'");
            alert("Login Successful");
            window.location.href = "http://localhost/Main/Main.html";
        </script>';
    }
    else {
        echo '<script>
            alert("Invalid Email & Password");
            window.location.href = "Login.html";
        </script>';
    }
}
else {
    echo '<script>
        alert("Invalid Email & Password");
        window.location.href = "Login.html";
    </script>';
}

$stmt->close();
$conn->close();
?>