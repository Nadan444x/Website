<?php
$conn =new mysqli('localhost','root','Rohit@444','website');
if ($conn->connect_error) {
    die('Connection Failed :'.$conn->connect_error);
}

$NAME1 = $_POST['Name'];
$Email1 = $_POST['Email'];

$stmt = $conn->prepare("SELECT * FROM registration_data WHERE Name =? AND Email = ?");
    $stmt->bind_param("ss", $NAME1, $Email1);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        echo '<script>
        alert("User Exist");
        window.location.href = "forget1.html";
    </script>';
    }
    else{
        echo'<script>
        alert("User Not Exist");
        window.location.href = "forget.html";
    </script>';
    }

    ?>