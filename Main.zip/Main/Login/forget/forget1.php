<?php
$conn =new mysqli('localhost','root','Rohit@444','website');
if ($conn->connect_error) {
    die('Connection Failed :'.$conn->connect_error);
}

$Email1 =$_POST['Email'];
$NewPassword = $_POST['Password'];
$ConfirmPassword = $_POST['Confirm_Password'];


if($Email1 ===$_POST['Email']){
    
if ($NewPassword === $ConfirmPassword) {
    // Hash the new password
    $hashedPassword = $ConfirmPassword;

$stmt = $conn->prepare("UPDATE registration_data SET Password = ? WHERE Email = ?");
$stmt->bind_param("ss", $hashedPassword, $Email1);
$stmt->execute();

echo '<script>
        alert("Password Forgeted......Redirecting to Login Page");
        window.location.href = "http://localhost/Vidya/Pages/New%20Login%20And%20sign%20Up/Login.html";
    </script>';
}
else{
    echo '<script>
    alert("Password not match OR Email is Wrong");
    window.location.href ="http://localhost/Vidya/Pages/New%20Login%20And%20sign%20Up/forget/forget1.html";
    </script>';

}}