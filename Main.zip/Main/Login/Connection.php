<?php
// Get form data
$_Name = $_POST['Name'];
$_Email = $_POST['Email'];
$_Password = $_POST['Password'];

// Database connection
$conn = new mysqli('localhost', 'root', 'Rohit@444', 'website');

if ($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
} else {
    // Check if the email is a Gmail address
    if (strpos($_Email, '@gmail.com') !== false) {
        // Check if the Gmail already exists in the database
        $checkStmt = $conn->prepare("SELECT Email FROM Registration_Data WHERE Email = ?");
        $checkStmt->bind_param("s", $_Email);
        $checkStmt->execute();
        $checkStmt->store_result();

        if ($checkStmt->num_rows > 0) {
            // Gmail already exists
            echo '<script>
                alert("This Gmail address is already registered.");
                window.location.href = "Login.html";    
            </script>';
            $checkStmt->close();
            $conn->close();
            exit(); // Stop further execution
        }
        $checkStmt->close();
    }

    // If Gmail does not exist, proceed with registration
    $stmt = $conn->prepare("INSERT INTO Registration_Data (Name, Email, Password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $_Name, $_Email, $_Password);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo '<script>
            alert("Registration Done! Redirecting to Login Page.");
            window.location.href = "Login.html";
        </script>';
    } else {
        echo '<script>
            alert("Registration failed. Please try again.");
            window.location.href = "Registration.html";
        </script>';
    }

    $stmt->close();
    $conn->close();
    exit();
}
?>